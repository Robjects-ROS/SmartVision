# Rubikcube > rb test training
https://universe.roboflow.com/gilbertopenayohck-gmail-com/rubikcube

Provided by a Roboflow user
License: Public Domain

